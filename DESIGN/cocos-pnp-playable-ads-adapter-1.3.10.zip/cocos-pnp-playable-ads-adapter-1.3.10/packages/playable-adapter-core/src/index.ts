export {
  TPlatform,
  TWebOrientations,
  TAdapterRC,
  TChannel,
} from './typings'

export {
  exec2xAdapter,
  exec3xAdapter,
} from './executor'
