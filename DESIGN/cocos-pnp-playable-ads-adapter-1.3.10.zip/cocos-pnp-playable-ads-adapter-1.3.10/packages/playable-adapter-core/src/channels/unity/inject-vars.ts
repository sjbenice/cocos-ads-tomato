// 将下面代码放入 body 中
export const INSERT_BEFORE_SCRIPT = `<script src="mraid.js"></script>`