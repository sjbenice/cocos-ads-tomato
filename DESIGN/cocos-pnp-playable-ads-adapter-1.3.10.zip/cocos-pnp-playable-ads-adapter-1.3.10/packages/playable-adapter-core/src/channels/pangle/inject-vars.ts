// 在head里面添加
export const APPEND_TO_HEAD = `<script src="https://sf-tb-sg.ibytedtos.com/obj/ttfe-malisg/playable/sdk/index.b5662ec443f458c8a87e.js"></script>`
