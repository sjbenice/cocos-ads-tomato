// 在head里面添加
export const APPEND_TO_HEAD = `<script src="https://sf16-muse-va.ibytedtos.com/obj/union-fe-nc-i18n/playable/sdk/playable-sdk.js"></script>`
