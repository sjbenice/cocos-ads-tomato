export const LANDSCAPE_META = `<meta name="ad.orientation" content="landscape"><meta name="ad.size" content="width=480,height=320">`
export const PORTRAIT_META = `<meta name="ad.orientation" content="portrait"><meta name="ad.size" content="width=320,height=480">`

export const AD_SDK_SCRIPT = `<script type="text/javascript" src="https://tpc.googlesyndication.com/pagead/gadgets/html5/api/exitapi.js"></script>`

export const SDK_EXIT_A_TAG = `<a onclick="ExitApi.exit()" style="display: none;"></a>`
