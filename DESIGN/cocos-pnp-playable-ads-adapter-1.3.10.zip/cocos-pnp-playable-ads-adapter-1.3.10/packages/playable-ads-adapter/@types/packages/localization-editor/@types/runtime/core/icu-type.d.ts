/**
 * Intl formatting
 */
declare enum ICUType {
    DateTime = 0,
    Number = 1,
    List = 2,
    RelativeTime = 3,
}
export default ICUType;
