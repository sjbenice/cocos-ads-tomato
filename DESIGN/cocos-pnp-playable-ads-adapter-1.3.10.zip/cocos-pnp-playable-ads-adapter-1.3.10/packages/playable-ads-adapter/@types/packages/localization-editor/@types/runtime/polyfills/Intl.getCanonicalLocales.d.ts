import '@formatjs/intl-getcanonicallocales';
